import pickle
import pandas as pd
import numpy as np
from flask import Flask,render_template,request,redirect,url_for
app = Flask(__name__)



filename="model.pkl"
loaded_model = pickle.load(open(filename, 'rb'))


html_label=['credit',
            'annuity',
            'age',
            'days',
            'external',
            'rating',
            'count',
            'income',
            'education',
            'gender',
            'contract',
            'car',
            'house_type',
            'suite',
            'status',
            'house',
            'source']

html_label_num=['credit',
            'annuity',
            'age',
            'days',
            'external',
            'rating',
            'count',
            'income']

html_label_cat=['education','gender','contract','car','house_type','suite','status','house','source']


lst_edu=["NAME_EDUCATION_TYPE_Academic degree",
"NAME_EDUCATION_TYPE_Higher education",
"NAME_EDUCATION_TYPE_Incomplete higher",
"NAME_EDUCATION_TYPE_Lower secondary",
"NAME_EDUCATION_TYPE_Secondary / secondary special"]

lst_gender=["CODE_GENDER_F",
"CODE_GENDER_M",
"CODE_GENDER_XNA"]

lst_loan=[
          "NAME_CONTRACT_TYPE_y_last_Cash loans",
"NAME_CONTRACT_TYPE_y_last_Consumer loans",
"NAME_CONTRACT_TYPE_y_last_Revolving loans",
"NAME_CONTRACT_TYPE_y_last_XNA"]
          
lst_car=["FLAG_OWN_CAR_N","FLAG_OWN_CAR_Y"]

lst_house=["FLAG_OWN_REALTY_N","FLAG_OWN_REALTY_Y"]

lst_suite=["NAME_TYPE_SUITE_y_last_Children",
"NAME_TYPE_SUITE_y_last_Family",
"NAME_TYPE_SUITE_y_last_Group of people",
"NAME_TYPE_SUITE_y_last_Other_A",
"NAME_TYPE_SUITE_y_last_Other_B",
"NAME_TYPE_SUITE_y_last_Spouse, partner",
"NAME_TYPE_SUITE_y_last_Unaccompanied"]

lst_family_status=['NAME_FAMILY_STATUS_Civil marriage',
 'NAME_FAMILY_STATUS_Married',
 'NAME_FAMILY_STATUS_Separated',
 'NAME_FAMILY_STATUS_Single / not married',
 'NAME_FAMILY_STATUS_Widow']

lst_house_type=['NAME_HOUSING_TYPE_Co-op apartment',
 'NAME_HOUSING_TYPE_House / apartment',
 'NAME_HOUSING_TYPE_Municipal apartment',
 'NAME_HOUSING_TYPE_Office apartment',
 'NAME_HOUSING_TYPE_Rented apartment',
 'NAME_HOUSING_TYPE_With parents']

lst_income=['NAME_INCOME_TYPE_Commercial associate',
 'NAME_INCOME_TYPE_Maternity leave',
 'NAME_INCOME_TYPE_Pensioner',
 'NAME_INCOME_TYPE_State servant',
 'NAME_INCOME_TYPE_Student',
 'NAME_INCOME_TYPE_Unemployed',
 'NAME_INCOME_TYPE_Working']







credit_min=45000
credit_max=4050000
annuity_min=1615
annuity_max=258025
income_min=1615
income_max=258025
days_min=0
days_max=2922
ext_min=0
ext_max=4.47
age_min=21
age_max=69

@app.route("/")
def home():
  return render_template("index.html")



@app.route('/predicts', methods=["GET","POST"])
def predicts():
  data=[]
  (edu,
   gender,
   loan,
   car,
   house,
   suite,
   family_status,
   house_type,
   income)=(np.zeros(len(lst_edu),dtype=int),
            np.zeros(len(lst_gender),dtype=int),
            np.zeros(len(lst_loan),dtype=int),
            np.zeros(len(lst_car),dtype=int),
            np.zeros(len(lst_house),dtype=int),
            np.zeros(len(lst_suite),dtype=int),
            np.zeros(len(lst_family_status),dtype=int),
            np.zeros(len(lst_house_type),dtype=int),
            np.zeros(len(lst_income),dtype=int))
                                                                  
  
  if request.method=="POST":
    for element in html_label_num:
          data.append(request.form[element])



    for element in html_label_cat:
        if element=='education':
            edu_type=request.form[element]
            for value in lst_edu:
                if value.endswith(edu_type):
                    f_index=value
                    index=lst_edu.index(f_index)
                    edu[index]=1

        if element=='gender':
            gen_type=request.form[element]
            for value in lst_gender:
                if value.endswith(gen_type):
                    f_index=value
                    index=lst_gender.index(f_index)
                    gender[index]=1
                
            
      
        
        if element=='contract':
            loan_type=request.form[element]
            for value in lst_loan:
                if value.endswith(loan_type):
                    f_index=value
                    index=lst_loan.index(f_index)
                    loan[index]=1
        
        if element=='car':
            car_type=request.form[element]
            for value in lst_car:
                if value.endswith(car_type):
                    f_index=value
                    index=lst_car.index(f_index)
                    car[index]=1
        
        if element=='house_type':
            house_cat=request.form[element]
            for value in lst_house_type:
                if value.endswith(house_cat):
                    f_index=value
                    index=lst_house_type.index(f_index)
                    house_type[index]=1


        if element=='suite':
            suite_type=request.form[element]
            for value in lst_suite:
                if value.endswith(suite_type):
                    f_index=value
                    index=lst_suite.index(f_index)
                    suite[index]=1

        if element=='status':
            status_type=request.form[element]
            for value in lst_family_status:
                if value.endswith(status_type):
                    f_index=value
                    index=lst_family_status.index(f_index)
                    family_status[index]=1

        if element=='house':
            house_type1=request.form[element]
            for value in lst_house:
                if value.endswith(house_type1):
                    f_index=value
                    index=lst_house.index(f_index)
                    house[index]=1

        if element=='source':
            income_type=request.form[element]
            for value in lst_income:
                if value.endswith(income_type):
                    f_index=value
                    index=lst_income.index(f_index)
                    income[index]=1

                    


        data[0]=(float(data[0])-credit_min)/(credit_max-credit_min)
        data[1]=(float(data[1])-annuity_min)/(annuity_max-annuity_min)
        data[7]=(float(data[7])-income_min)/(income_max-income_min)
        data[2]=(float(data[2])-age_min)/(age_max-age_min)
        data[4]=(abs(float(data[4]))-ext_min)/(ext_max-ext_min)
        data[3]=(abs(float(data[3]))-days_min)/(days_max-days_min)
        data[6]=float(data[6])
        data[5]=float(data[5])
        
        


            
        lst=[edu,gender,loan,car,house,suite,family_status,house_type,income]
        #lst=[lst_edu,lst_gender,lst_loan,lst_car,lst_house,lst_suite,lst_family_status,lst_house_type,lst_income]
        info=[data[0],data[1],data[5],data[7],data[3],data[4],data[6],data[2]]
        for item in lst:
            info.extend(item)
        
        result=loaded_model.predict([info])
        if 1:
          ans="Will default"
        else:
          ans="Will not default"
        
  return render_template("index.html",ans=ans)




if __name__=='__main__':
    app.run(debug=False)
